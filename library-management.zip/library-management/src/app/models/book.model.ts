export interface Categorie {
  id: number;
  nom: string;
}

export interface Book {
  id: number;
  titre: string;
  auteur: string;
  categorie: Categorie;
  disponible: boolean;
  image: string; // URL ou chemin de l'image du livre
}
