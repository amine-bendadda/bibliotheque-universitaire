export interface Role {
    id: number;
    nom: string; // e.g., 'ROLE_USER', 'ROLE_ADMIN'
  }
  