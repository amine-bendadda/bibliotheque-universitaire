import { Component, OnInit } from '@angular/core';
import { BookService } from '../services/book.service';
import { Book } from '../../../models/book.model';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; // Importer FormsModule pour [(ngModel)]

@Component({
  standalone: true, // Indique que c'est un composant autonome
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css'],
  imports: [CommonModule, FormsModule], // Importer CommonModule et FormsModule pour utiliser *ngIf, *ngFor, et [(ngModel)]
})
export class BookListComponent implements OnInit {
  books: Book[] = [];
  filteredBooks: Book[] = [];
  categories: string[] = ['Toutes']; // Liste des catégories disponibles
  searchQuery: string = ''; // Valeur du champ de recherche
  selectedCategory: string = 'Toutes'; // Valeur du filtre par catégorie
  filterByAvailability: string = 'Tous'; // Valeur du filtre par disponibilité (Tous, Disponible, Non disponible)
  errorMessage: string = '';

  constructor(private bookService: BookService) {}

  ngOnInit(): void {
    // Récupérer les livres depuis le service
    this.bookService.getBooks().subscribe({
      next: (data) => {
        console.log('Books in component:', data); // Log pour vérifier
        this.books = data;
        this.filteredBooks = data;

        // Extraire les catégories uniques
        const categoryNames = data
          .map((book) => book.categorie?.nom)
          .filter((nom) => nom !== undefined) as string[];
        this.categories = ['Toutes', ...new Set(categoryNames)];
      },
      error: (err) => {
        console.error('Error fetching books:', err);
        this.errorMessage = 'Une erreur s\'est produite lors de la récupération des livres.';
      },
    });
  }

  // Méthode pour mettre à jour les livres affichés en fonction des filtres
  onSearchChange(): void {
    this.filterBooks();
  }

  onCategoryChange(): void {
    this.filterBooks();
  }

  onAvailabilityChange(): void {
    this.filterBooks();
  }

  private filterBooks(): void {
    this.filteredBooks = this.books.filter((book) => {
      const matchesSearch =
        this.searchQuery === '' ||
        book.titre.toLowerCase().includes(this.searchQuery.toLowerCase());

      const matchesCategory =
        this.selectedCategory === 'Toutes' ||
        book.categorie?.nom === this.selectedCategory;

      const matchesAvailability =
        this.filterByAvailability === 'Tous' ||
        (this.filterByAvailability === 'Disponible' && book.disponible) ||
        (this.filterByAvailability === 'Non disponible' && !book.disponible);

      return matchesSearch && matchesCategory && matchesAvailability;
    });
  }
}
