import { Component } from '@angular/core';

@Component({
  selector: 'app-borrow-history',
  imports: [],
  templateUrl: './borrow-history.component.html',
  styleUrl: './borrow-history.component.css'
})
export class BorrowHistoryComponent {

}
