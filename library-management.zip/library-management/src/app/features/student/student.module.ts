import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { StudentRoutingModule } from './student-routing.module';
import { BookListComponent } from './book-list/book-list.component'; // Assurez-vous du bon chemin

@NgModule({
  imports: [
    CommonModule, // Nécessaire pour les directives Angular comme *ngIf et *ngFor
    StudentRoutingModule,
    BookListComponent,
    FormsModule, // Import direct du composant standalone ici
  ],
})
export class StudentModule {}
