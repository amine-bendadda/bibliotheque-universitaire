import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-books',
  imports: [],
  templateUrl: './manage-books.component.html',
  styleUrl: './manage-books.component.css'
})
export class ManageBooksComponent {

}
