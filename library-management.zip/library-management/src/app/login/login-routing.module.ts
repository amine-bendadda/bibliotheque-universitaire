import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login.component';
import { AuthGuard } from './services/auth.guard'; // AuthGuard pour protéger les routes

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  // Redirection basée sur les rôles après authentification
  {
    path: 'admin',
    loadChildren: () =>
      import('../features/admin/admin.module').then((m) => m.AdminModule),
    canActivate: [AuthGuard],
    data: { role: 'ADMIN' }, // Vérifie si l'utilisateur a un rôle d'administrateur
  },
  {
    path: 'student',
    loadChildren: () =>
      import('../features/student/student.module').then((m) => m.StudentModule),
    canActivate: [AuthGuard],
    data: { role: 'STUDENT' }, // Vérifie si l'utilisateur a un rôle d'étudiant
  },
  { path: '**', redirectTo: 'login' }, // Redirection pour les routes non définies
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
