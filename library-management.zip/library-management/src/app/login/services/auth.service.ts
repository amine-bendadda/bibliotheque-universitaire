import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private isLoggedIn = false;
  private userRole: string | null = null;

  login(email: string, password: string): boolean {
    // Effectuer l'authentification via un appel API
    // Simuler l'authentification pour l'exemple
    if (email === 'admin@example.com' && password === 'admin123') {
      this.isLoggedIn = true;
      this.userRole = 'ADMIN';
    } else if (email === 'student@example.com' && password === 'student123') {
      this.isLoggedIn = true;
      this.userRole = 'STUDENT';
    }
    return this.isLoggedIn;
  }

  logout(): void {
    this.isLoggedIn = false;
    this.userRole = null;
  }

  isAuthenticated(): boolean {
    return this.isLoggedIn;
  }

  getUserRole(): string | null {
    return this.userRole;
  }
}
