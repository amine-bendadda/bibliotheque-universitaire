import { NavbarComponent } from './navbar/navbar.component';

export const sharedComponents = [
  NavbarComponent, // Déclaration du composant navbar
];
