import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: '/student', pathMatch: 'full' },
  {
    path: 'student',
    loadChildren: () => import('./features/student/student.module').then(m => m.StudentModule),
  },
  {
    path: 'admin',
    loadChildren: () => import('./features/admin/admin.module').then(m => m.AdminModule),
  },
];
