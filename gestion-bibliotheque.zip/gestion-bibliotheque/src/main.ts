import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { appConfig } from './app/app.config';
import { initializeKeycloak } from './app/app.keycloak.config';

const isBrowser = typeof window !== 'undefined';

if (isBrowser) {
  initializeKeycloak()
    .then(() => bootstrapApplication(AppComponent, appConfig))
    .catch((err) => console.error('Keycloak initialization failed:', err));
} else {
  console.warn('Keycloak initialization skipped: Running on server side.');
}
