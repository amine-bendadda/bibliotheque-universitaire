import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard-student',
  imports: [],
  templateUrl: './dashboard-student.component.html',
  styleUrl: './dashboard-student.component.css'
})
export class DashboardStudentComponent {

}
