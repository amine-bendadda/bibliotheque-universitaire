import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Router,
} from '@angular/router';
import { KeycloakService } from 'keycloak-angular';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  constructor(private keycloak: KeycloakService, private router: Router) {}

  async canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Promise<boolean> {
    if (typeof window === 'undefined') {
      console.warn('AuthGuard skipped: Running on server side.');
      return false;
    }

    const isAuthenticated = await this.keycloak.isLoggedIn();
    const token = await this.keycloak.getToken();

    if (!token) {
      console.error('No token found. Redirecting to unauthorized page.');
      this.router.navigate(['/unauthorized']);
      return false;
    }

    const decodedToken = JSON.parse(atob(token.split('.')[1])); // Décodage du token
    const roles = decodedToken.realm_access?.roles || []; // Rôles globaux

    const requiredRoles = route.data['roles'] as Array<string>;
    if (
      isAuthenticated &&
      (!requiredRoles || requiredRoles.some((role) => roles.includes(role)))
    ) {
      return true;
    }

    this.router.navigate(['/unauthorized']);
    return false;
  }
}
