import { Routes } from '@angular/router';
import { DashboardStudentComponent } from './dashboard-student/dashboard-student.component';
import { DashboardAdminComponent } from './dashboard-admin/dashboard-admin.component';
import { UnauthorizedComponent } from './unauthorized/unauthorized.component';
import { AuthGuard } from './auth.guard';

export const routes: Routes = [
  {
    path: 'dashboard-student',
    component: DashboardStudentComponent,
    canActivate: [AuthGuard],
    data: { roles: ['ROLE_USER'] },
  },
  {
    path: 'dashboard-admin',
    component: DashboardAdminComponent,
    canActivate: [AuthGuard],
    data: { roles: ['ROLE_ADMIN'] },
  },
  {
    path: 'unauthorized',
    component: UnauthorizedComponent,
  },
  { path: '', redirectTo: 'dashboard-student', pathMatch: 'full' },
];
