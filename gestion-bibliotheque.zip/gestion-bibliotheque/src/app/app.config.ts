import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideClientHydration, withEventReplay } from '@angular/platform-browser';
import { KeycloakService } from 'keycloak-angular';
import { routes } from './app.routes';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideClientHydration(withEventReplay()),
    {
      provide: KeycloakService,
      useFactory: () => {
        if (typeof window === 'undefined') {
          console.warn('Keycloak not initialized: Server-side rendering detected.');
          return null; // Retourne une valeur vide pour SSR
        }
        const keycloak = new KeycloakService();
        keycloak.init({
          config: {
            url: 'http://localhost:8080',
            realm: 'bibliotheque',
            clientId: 'angular-client',
          },
          initOptions: {
            onLoad: 'login-required',
            checkLoginIframe: false,
          },
        });
        return keycloak;
      },
    },
  ],
};
