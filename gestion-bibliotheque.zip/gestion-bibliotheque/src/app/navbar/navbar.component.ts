import { Component } from '@angular/core';
// import { keycloak } from '../app.keycloak.config';

@Component({
  selector: 'app-navbar',
  standalone: true,
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
})
export class NavbarComponent {
  logout(): void {
    // keycloak.logout();
  }
}