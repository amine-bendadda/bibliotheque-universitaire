// import Keycloak from 'keycloak-js';

// export const keycloakConfig = {
//   url: 'http://localhost:8080', // URL de Keycloak
//   realm: 'bibliotheque',        // Nom du realm
//   clientId: 'angular-client',   // Nom du client
// };

// export const keycloak = new Keycloak({
//   url: keycloakConfig.url,
//   realm: keycloakConfig.realm,
//   clientId: keycloakConfig.clientId,
// });


import Keycloak from 'keycloak-js';

export const initializeKeycloak = async () => {
  if (typeof window === 'undefined') {
    console.warn('Keycloak initialization skipped: Running on server side.');
    return Promise.resolve(); // Retourne une promesse résolue pour éviter les erreurs
  }

  const keycloak = new Keycloak({
    url: 'http://localhost:8080',
    realm: 'bibliotheque',
    clientId: 'angular-client',
  });

  return keycloak
    .init({
      onLoad: 'login-required',
      checkLoginIframe: false,
    })
    .then((authenticated) => {
      console.log('Keycloak initialized:', authenticated);
    })
    .catch((err) => {
      console.error('Keycloak initialization failed:', err);
    });
};
