import {
  keycloak_default
} from "./chunk-ORZKCZ3A.js";
import "./chunk-WDMUDEB6.js";
export {
  keycloak_default as default
};
//# sourceMappingURL=keycloak-js.js.map
